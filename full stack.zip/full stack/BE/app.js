// //import library
// const express = require("express");
// const app = express();
// const bodyparser = require("body-parser");
// const router = require("./router/routers.js");
// const cors = require("cors");

// //add middlewares
// app.use(bodyparser.urlencoded({ extended: false }));
// app.use(bodyparser.json());

// //configure the application
// app.use(
//   cors({
//     origin: "http://localhost:3000", // Replace with the URL of your React app
//     credentials: true, // Enable sending cookies from the React app
//   })
// );

// //add url handler
// app.use("/", router);

// //start the server
// app.listen(3002, function () {
//   console.log("server running at port 3002");
// });
// //export app
// module.exports = app;

const express = require("express");

const app = express();
const bodyparser = require("body-parser");
const router = require("./router/routers");
const cors = require("cors");
app.use(
  cors({
    origin: "http://localhost:3000", // Replace with the URL of your React app
    credentials: true, // Enable sending cookies from the React app
  })
);
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());

app.use("/", router);
app.listen(3002, () => console.log("server listening at 3002"));

module.exports = app;
