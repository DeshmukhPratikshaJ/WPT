const HomeComponent=()=>{
  return (
    <h1>In home component</h1>
  )
}

export default HomeComponent;